﻿using UnityEngine;
using System.Collections;

public class Cursor : MonoBehaviour 
{
	//Hotspot Offset
	public Vector2 CursorOffset = Vector2.zero;
	
	//Override system cursor?
	public bool ShowSystemCursor = false;
	
	//Speed of cursor movment for keyboard override (pixels per second)
	public float CursorSpeed = 100.0f;
	
	//Should enable keyboard override?
	public bool EnableKeyboardOverride = false;
	
	//Transform component
	private Transform ThisTransform = null;
		
	// Use this for initialization
	void Start () 
	{
		//Cache transform
		ThisTransform = transform;
		
		//Hide or show system cursor
		Screen.showCursor = ShowSystemCursor;
	}
	
	// Update is called once per frame
	void Update () 
	{
		#if UNITY_STANDALONE || UNITY_EDITOR || UNITY_WEBPLAYER || UNITY_DASHBOARD_WIDGET
		
		//Should we control cursor movement with keyboard?
		if(EnableKeyboardOverride)
		{
			//Amount of Movement
			float Move = CursorSpeed * Time.deltaTime;
			
			//Update keyboard movement
			ThisTransform.Translate(Move * Input.GetAxis("Horizontal") * Move, Input.GetAxis("Vertical") * Move, 0);
		
			return;
		}
		
		//No keyboard override. Update with mouse movement
		
		//Update position from mouse movement
		ThisTransform.position = new Vector3(Input.mousePosition.x + CursorOffset.x, Input.mousePosition.y + CursorOffset.y, ThisTransform.position.z);
		
		#endif
	}
}
