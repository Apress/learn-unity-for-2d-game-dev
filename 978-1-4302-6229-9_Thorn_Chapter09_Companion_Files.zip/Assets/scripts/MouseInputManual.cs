﻿using UnityEngine;
using System.Collections;

public class MouseInputManual : MonoBehaviour
{
	// Update is called once per frame
	void Update () 
	{
		#if UNITY_STANDALONE || UNITY_EDITOR || UNITY_WEBPLAYER || UNITY_DASHBOARD_WIDGET
		//Clicked mouse button
		if (Input.GetMouseButtonDown(0)) 
		{
			//Generate ray from main camera and mouse position
			Ray R = Camera.main.ScreenPointToRay(Input.mousePosition);
			
			//Will store info about all intersections
			RaycastHit[] HitInfo = Physics.RaycastAll(R);
	
			//Test to see if ray intersects with any colliders
			if (HitInfo != null)
			{
				//Loop through all intersections
				foreach (RaycastHit Hit in HitInfo)
				{
					//Object was hit, get game object that was hit
					GameObject HitObject = Hit.collider.gameObject;
					
					//Print GameObject name to console
					Debug.Log (HitObject.name);
				}
			}
		}
		#endif
	}
}
