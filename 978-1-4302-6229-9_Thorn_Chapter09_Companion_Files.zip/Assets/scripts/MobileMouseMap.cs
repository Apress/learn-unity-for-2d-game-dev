﻿using UnityEngine;
using System.Collections;

public class MobileMouseMap : MonoBehaviour 
{
	// Update is called once per frame
	void Update () 
	{
		#if UNITY_IPHONE || UNITY_ANDROID || UNITY_BLACKBERRY || UNITY_WP8
		if(Input.touchCount>0)
		{
			//Screen position of touch
			Vector2 TouchLocation = Input.GetTouch(0).position;
			
			//Get phase of touch
			TouchPhase TPhase = Input.GetTouch(0).phase;
				
			//Touch begins
			if(TPhase.Equals(TouchPhase.Began))
			{
				//Generate ray from main camera and mouse position
				Ray R = Camera.main.ScreenPointToRay(TouchLocation);
				RaycastHit HitInfo;
				
				//If intersection
				if(Physics.Raycast(R, out HitInfo))
				{
					//Click equivalent - call mouse event
					HitInfo.collider.gameObject.SendMessage("OnMouseDown");
				}
			}
		}
		#endif
	}
}
