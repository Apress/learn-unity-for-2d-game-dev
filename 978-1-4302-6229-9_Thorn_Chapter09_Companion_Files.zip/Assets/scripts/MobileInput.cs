﻿using UnityEngine;
using System.Collections;

public class MobileInput : MonoBehaviour 
{
	// Update is called once per frame
	void Update () 
	{
		#if UNITY_IPHONE || UNITY_ANDROID || UNITY_BLACKBERRY || UNITY_WP8	
		if(Input.touchCount>0)
		{
			for(int i =0; i<Input.touchCount; i++)
			{
				//Screen position of touch
				Vector2 TouchLocation = Input.GetTouch(0).position;
			
				//Get phase of touch
				TouchPhase TPhase = Input.GetTouch(0).phase;
				
				//Touch begins
				if(TPhase.Equals(TouchPhase.Began))
				{
					//Click equivalent
				}
			}
		}
		#endif
	}
}
