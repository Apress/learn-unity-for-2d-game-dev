﻿using UnityEngine;
using System.Collections;

public class ObjectTouch : MonoBehaviour
{	
	//Called on mouse down
	void OnMouseDown()
	{
		Debug.Log ("You clicked me");
	}
}
