﻿//Singleton class to manage game progress
using UnityEngine;
using System.Collections;

public class GameManager : MonoBehaviour
{
	
	//Player Types
	public enum PLAYER_TYPE {SERVER_PLAYER = 0, CLIENT_PLAYER = 1};
	
	//Type taking their turn now
	public PLAYER_TYPE ActivePlayer = PLAYER_TYPE.SERVER_PLAYER;
	
	//Player Scores
	public int[] PlayerScores;
	
	//Public properties
	//------------------------------------------------
	//Number of consecutive matches player must make for each card type to complete turn
	public int NumMatches = 3;
	
	//Lose interval - amount of time in seconds to pause before clearing cards and resetting turn (When player makes a mistake)
	public float LoseInterval = 1.0f;
	
	//Win interval - amount of time in seconds to pause before clearing cards and resetting turn (When player matches 3)
	public float WinInterval = 1.0f;
	
	//Num points to earn for match 3
	public int Points = 10;
	
	//-----------------------------------------
	
	//Private properties
	//Reference to all card objects in the scene
	private GameObject[] CardObjects = null;
	
	//Internal Turn Step Counter (keeps track of how many cards picked so far
	private int TurnStep = 0;
	
	//List of cards picked this turn so far
	private GameObject[] SelectedCards = null;
	
	//Input enabled for this machine
	private bool InputEnabled = true;
	
	//Render component for mouse cursor
	private MeshRenderer CursorRender = null;
	
	//-----------------------------------------
	void Start()
	{
		//Get all card objects
		CardObjects = GameObject.FindGameObjectsWithTag("Card") as GameObject[];
		
		//Get mouse cursor render component
		CursorRender = GameObject.FindGameObjectWithTag("Cursor").GetComponent<MeshRenderer>();
		
		//Setup scores
		PlayerScores = new int[2];
		
		//Start scores at 0
		for(int i = 0; i < PlayerScores.Length; i++)
			PlayerScores[i] = 0;
		
		//Created selected card array
		SelectedCards = new GameObject[NumMatches];
		
		//Disable input until told to start
		EnableInput(false);
	}
	//-----------------------------------------
	void Update()
	{
		HandleInput();
	}
	//-----------------------------------------
	//Resets and Shuffles Cards
	public void Shuffle()
	{
		//If not server then no need for shuffle
		if(!Network.isServer) return;
		
		//Reset all cards to starting states
		foreach(GameObject CardObject in CardObjects)
			UpdateCardStatus(CardObject, Card.CARD_STATE.CARD_CONCEALED);
		
		//CardObject.SendMessage("SetCardState", Card.CARD_STATE.CARD_CONCEALED, SendMessageOptions.DontRequireReceiver);
		
		//Cycle through all cards and exchange for shuffle
		foreach(GameObject Card in CardObjects)
		{
			//Get Transform
			Transform CardTransform = Card.transform;
			
			//Get another random card to exchange position
			Transform ExchangeTransform = CardObjects[Mathf.FloorToInt(Random.Range(0, CardObjects.Length-1))].transform;
			
			//Exchange positions
			Vector3 TmpPosition = CardTransform.localPosition;
			
			CardTransform.localPosition = ExchangeTransform.localPosition;
			ExchangeTransform.localPosition = TmpPosition;
		}
	}
	//-----------------------------------------
	//Handle user input
	public void HandleInput()
	{
		//Ignore disabled input
		if(!InputEnabled) return;
		
		//Ignore if no input
		if(!Input.GetMouseButtonDown(0) && Input.touchCount <= 0) return;
		
		//Tap Position
		Vector3 TapPosition = Vector3.zero;
		
		//Handle desktop input
		#if UNITY_STANDALONE || UNITY_WEBPLAYER
			TapPosition = Input.mousePosition;
		#endif
		
		//Handle mobile input
		#if UNITY_IPHONE || UNITY_ANDROID || UNITY_WP8
			Touch T = Input.GetTouch(0);
		
			if(T.phase == TouchPhase.Began)
				TapPosition = T.position;
			else
				return; //Not required touch type
		#endif
		
		//Generate ray from touch position
		Ray R = Camera.main.ScreenPointToRay(TapPosition);
		
		//Get hits in scene to detect card selection
		RaycastHit[] Hits;
		
		Hits = Physics.RaycastAll(R);
		
		//Cycle through hits
		foreach(RaycastHit H in Hits)
		{
			//Play step
			PickCard (H.collider.gameObject);
			return;
		}
	}
	//-----------------------------------------
	//Function to enable/disable input
	[RPC]
	public void EnableInput(bool bEnabled = true)
	{
		//Set input enabled flag and show/hide cursor graphic
		CursorRender.enabled = InputEnabled = bEnabled;
	}
	//-----------------------------------------
	//Function to pick a card and update turn
	public void PickCard(GameObject SelectedCard)
	{
		//Pick card
		//SelectedCard.SendMessage("SetCardState", Card.CARD_STATE.CARD_REVEALED, SendMessageOptions.DontRequireReceiver);
		UpdateCardStatus(SelectedCard, Card.CARD_STATE.CARD_REVEALED);
		UpdateTurn(SelectedCard);
	}
	//-----------------------------------------
	//Function to start new turn for local player
	public void StartTurn()
	{
		if(!Network.isServer) return;
		
		//Reset Step Counter
		TurnStep = 0;
		
		//Clear Selected Array
		for(int i = 0; i<SelectedCards.Length; i++)
			SelectedCards[i]=null;
	}
	//-----------------------------------------
	//Function to Update Turn
	public void UpdateTurn(GameObject PickedCard)
	{
		if(!Network.isServer) return;
		
		//Add card to selected array
		SelectedCards[TurnStep] = PickedCard;
			
		//Increment turn step
		++TurnStep;
		
		//Should we exit now?
		if(TurnStep <= 1) return;
		
		//If picked more than one card in sequence, then check is the same
		if(SelectedCards[TurnStep-1].GetComponent<MeshFilter>().mesh.name != SelectedCards[TurnStep-2].GetComponent<MeshFilter>().mesh.name)
		{
			//Is not same. Player made mistake. Reset turn for next player.
			StartCoroutine(LoseTurn());
			return;
		}
		
		//Player made successful match. Is end of turn?
		if(TurnStep >= NumMatches)
		{
			//Player made all matches. Move to next turn
			StartCoroutine(WinTurn());
		}
	}
	//-----------------------------------------
	//Ends turn as loss condition
	public IEnumerator LoseTurn()
	{
		if(!Network.isServer) yield break;
		
		//Disable input
		EnableInput(false);
		networkView.RPC("EnableInput", RPCMode.OthersBuffered, false);
		
		//Wait for lost interval
		yield return new WaitForSeconds(LoseInterval);
		
		//Restore revealed cards
		for(int i=0; i<SelectedCards.Length; i++)
		{
			//If valid selection, then restore
			if(SelectedCards[i])
				UpdateCardStatus(SelectedCards[i], Card.CARD_STATE.CARD_CONCEALED);
			
			//SelectedCards[i].SendMessage("SetCardState", Card.CARD_STATE.CARD_CONCEALED, SendMessageOptions.DontRequireReceiver);
		}
		
		//Restart turn
		StartTurn();
		
		//Change player
		if(ActivePlayer == PLAYER_TYPE.SERVER_PLAYER)
			ChangePlayer(PLAYER_TYPE.CLIENT_PLAYER);
		else
			ChangePlayer(PLAYER_TYPE.SERVER_PLAYER);
	}
	//-----------------------------------------
	void OnGUI()
	{
		if(Network.isServer)
			GUI.Box(new Rect(0,0,300,100), "Your Score: " + PlayerScores[(int)PLAYER_TYPE.SERVER_PLAYER] + " Your Opponent's Score: " + PlayerScores[(int)PLAYER_TYPE.CLIENT_PLAYER]);
		else
			GUI.Box(new Rect(0,0,300,100), "Your Score: " + PlayerScores[(int)PLAYER_TYPE.CLIENT_PLAYER] + " Your Opponent's Score: " + PlayerScores[(int)PLAYER_TYPE.SERVER_PLAYER]);
	}
	//-----------------------------------------
	[RPC]
	void SetScore(int ServerScore, int ClientScore)
	{
		PlayerScores[(int)PLAYER_TYPE.SERVER_PLAYER] = ServerScore;
		PlayerScores[(int)PLAYER_TYPE.CLIENT_PLAYER] = ClientScore;
	}
	//-----------------------------------------
	//Change player
	public void ChangePlayer(PLAYER_TYPE Type)
	{
		//Make active
		ActivePlayer = Type;
		
		if(ActivePlayer == PLAYER_TYPE.SERVER_PLAYER)
		{
			EnableInput(true);
			networkView.RPC("EnableInput", RPCMode.OthersBuffered, false);
			return;
		}
			
		if(ActivePlayer == PLAYER_TYPE.CLIENT_PLAYER)
		{
			EnableInput(false);
			networkView.RPC("EnableInput", RPCMode.OthersBuffered, true);
			return;
		}
	}
	//-----------------------------------------
	//Ends turn as win condition
	public IEnumerator WinTurn()
	{
		if(!Network.isServer) yield break;
		
		//Disable input
		EnableInput(false);
		networkView.RPC("EnableInput", RPCMode.OthersBuffered, false);
		
		//Wait for lost interval
		yield return new WaitForSeconds(WinInterval);
		
		//Hide revealed cards
		for(int i=0; i<SelectedCards.Length; i++)
		{
			//If valid selection, then restore
			if(SelectedCards[i])
				UpdateCardStatus(SelectedCards[i], Card.CARD_STATE.CARD_HIDDEN);
				
			//SelectedCards[i].SendMessage("SetCardState", Card.CARD_STATE.CARD_HIDDEN, SendMessageOptions.DontRequireReceiver);
		}
		
		
		//Check if there are cards remaining on board?
		bool CardsRemaining = false;
		
		foreach(GameObject CardObj in CardObjects)
		{
			if(CardObj.GetComponent<Card>().ActiveState != Card.CARD_STATE.CARD_HIDDEN)
			{
				CardsRemaining = true;
				break;
			}
		}
		
		if(CardsRemaining)
		{
			//Move to next turn
			StartTurn();
		}
		
		//Update Scores
		PlayerScores[(int)ActivePlayer] += Points;
		
		object[] Scores = new object[2];
		Scores[0] = PlayerScores[(int)PLAYER_TYPE.SERVER_PLAYER];
		Scores[1] = PlayerScores[(int)PLAYER_TYPE.CLIENT_PLAYER];
		networkView.RPC("SetScore", RPCMode.OthersBuffered, Scores);

		if(ActivePlayer == PLAYER_TYPE.SERVER_PLAYER)
			EnableInput(true);
		else
			networkView.RPC("EnableInput", RPCMode.OthersBuffered, true);
	}
	//-----------------------------------------
	//Remote Procedure Call to Update Card Status
	[RPC]
	public void UpdateCardStatus(string CardObject, int State)
	{
		//Pass on message
		PickCard(GameObject.Find(CardObject));
	}
	//-----------------------------------------
	public void UpdateCardStatus(GameObject CardObject, Card.CARD_STATE State)
	{
		//If client then send data to server
		if(Network.isClient)
		{
			object[] Args = new object[2];
			Args[0]=CardObject.name;
			Args[1]=(int)State;
			
			networkView.RPC("UpdateCardStatus",RPCMode.OthersBuffered, Args);
		}
		else //Update Directly
			CardObject.SendMessage("SetCardState", State, SendMessageOptions.DontRequireReceiver);
	}
	//-----------------------------------------
	//Called when connecting as client
	void OnPlayerConnected()
	{
		//Connection established between players. Start round and enable input
		//Server player takes turn first
		
		//Shuffle Cards
		Shuffle();
		
		//Start turn and begin turns cycle
		StartTurn();
		
		//Enable input
		EnableInput(true);
		
		//Set active player
		ActivePlayer = PLAYER_TYPE.SERVER_PLAYER;
	}
	//-----------------------------------------
}
