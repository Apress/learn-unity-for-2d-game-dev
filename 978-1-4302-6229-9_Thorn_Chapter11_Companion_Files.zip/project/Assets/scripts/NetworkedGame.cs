﻿using UnityEngine;
using System.Collections;

public class NetworkedGame : MonoBehaviour
{
	//-----------------------------------------
	// Use this for initialization
	void Start () 
	{
		//Refresh host list
		RefreshHostList();
	}
	//-----------------------------------------
	//Function refresh to host list
	public void RefreshHostList()
	{
		//Clear any existing host list
		MasterServer.ClearHostList();
		
		//Populate new host list for game type
		MasterServer.RequestHostList("UNITY2D_TILEMATCH_01");
	}
	//-----------------------------------------
	//Called when object is destroyed
	void OnDestroy()
	{
		//Disconnect
		Network.Disconnect();
		
		//Unregister from Master Server
		if(Network.isServer)
			MasterServer.UnregisterHost();
	}
	//-----------------------------------------
	//Be server
	public void BeServer()
	{
		print ("being server");
		//Create server
		Network.InitializeServer(2, 25000, !Network.HavePublicAddress());
		
		//Register as host for a game
		MasterServer.RegisterHost("UNITY2D_TILEMATCH_01", "TurnGame_01", "Test for Unity 2D Game Book");
	}
	//-----------------------------------------
	//Be client
	public void BeClient()
	{
		print ("being client");
		
		//Get Host data
		HostData[] HD = MasterServer.PollHostList();
		
		//Exit. No host found
		if(HD.Length <= 0) return;
		
		//Connect to first host
		Network.Connect(HD[0]);
	}
	//-----------------------------------------
	//Called on feedback from master server
	void OnMasterServerEvent(MasterServerEvent msEvent)
	{	
		switch(msEvent)
		{
			//Called when host list is received from server
			case MasterServerEvent.HostListReceived:
			
			//If we are already a client or server, then ignore
			if(Network.isClient || Network.isServer) return;
			
			//We receive host list. Now Check for existing hosts
			
			//If no current hosts, then be server
			if(MasterServer.PollHostList().Length <= 0)
				BeServer(); //Act as a new host
			else
				BeClient(); //Connect to existing host
			
			break;
		}
	}
	//-----------------------------------------

}
