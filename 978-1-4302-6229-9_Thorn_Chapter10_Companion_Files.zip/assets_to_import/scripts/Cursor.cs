﻿using UnityEngine;
using System.Collections;

public class Cursor : MonoBehaviour 
{
	//Hotspot Offset
	public Vector2 CursorOffset = Vector2.zero;
	
	//Override system cursor?
	public bool ShowSystemCursor = false;
	
	//Transform component
	private Transform ThisTransform = null;
		
	// Use this for initialization
	void Start () 
	{
		//Cache transform
		ThisTransform = transform;
		
		//Hide or show system cursor
		Screen.showCursor = ShowSystemCursor;
	}
	
	// Update is called once per frame
	void Update () 
	{
		#if UNITY_STANDALONE || UNITY_EDITOR || UNITY_WEBPLAYER || UNITY_DASHBOARD_WIDGET
		
		//Update position from mouse movement
		ThisTransform.position = new Vector3(Input.mousePosition.x + CursorOffset.x, Input.mousePosition.y + CursorOffset.y, ThisTransform.position.z);
		
		#endif
	}
}
