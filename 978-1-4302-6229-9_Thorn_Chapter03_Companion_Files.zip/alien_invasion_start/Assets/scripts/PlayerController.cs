using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour
{	
	//Player move speed in units per second
	public float Speed = 10.0f;
		
	//Player min and max X position in world space (to keep player in screen)
	public Vector2 MinMaxX = Vector2.zero;
	
		
	// Update is called once per frame
	void Update () 
	{
		transform.position = new Vector3(Mathf.Clamp(transform.position.x + Input.GetAxis("Horizontal") * Speed * Time.deltaTime, MinMaxX.x, MinMaxX.y), transform.position.y, transform.position.z);
	}
		
}