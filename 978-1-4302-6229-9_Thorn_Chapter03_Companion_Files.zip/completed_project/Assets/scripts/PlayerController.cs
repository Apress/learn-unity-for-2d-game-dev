using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour
{
	//Player health
	public int Health = 100;
	
	//Player move speed in units per second
	public float Speed = 10.0f;
	
	//Player reload delay in ms
	public float ReloadDelay = 0.2f;
	
	//Player min and max X position in world space (to keep player in screen)
	public Vector2 MinMaxX = Vector2.zero;
	
	//Prefab to instantiate
	public GameObject PrefabAmmo = null;
	
	//Gun position
	public GameObject GunPosition = null;
	
	//Can fire ammo
	private bool WeaponsActivated = true;
	
	// Update is called once per frame
	void Update () 
	{
		transform.position = new Vector3(Mathf.Clamp(transform.position.x + Input.GetAxis("Horizontal") * Speed * Time.deltaTime, MinMaxX.x, MinMaxX.y), transform.position.y, transform.position.z);
	}
	
	//Check input
	void LateUpdate()
	{
		//If fire button press, then shoot ammo
		if(Input.GetButton("Fire1") && WeaponsActivated)	
		{
			//Create new ammo object
			Instantiate(PrefabAmmo, GunPosition.transform.position, PrefabAmmo.transform.rotation);
			
			//Deactivate weapons
			WeaponsActivated = false;
			
			Invoke("ActivateWeapons", ReloadDelay);
		}
	}
	
	//Enable fire
	void ActivateWeapons()
	{
		WeaponsActivated = true;
	}
}
