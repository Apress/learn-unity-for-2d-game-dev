using UnityEngine;
using System.Collections;

public class EnemyController : MonoBehaviour 
{
	//Enemy health
	public int Health = 100;
	
	//Enemy move speed in units per second
	public float Speed = 10.0f;
	
	//Enemy reload delay in ms
	public float ReloadDelay = 0.2f;
	
	//Enemy min and max X position in world space (to keep Enemy in screen)
	public Vector2 MinMaxX = Vector2.zero;
	
	// Update is called once per frame
	void Update () 
	{
		//Ping pong enemy position
		transform.position = new Vector3(MinMaxX.x + Mathf.PingPong(Time.time * Speed, 1.0f) * (MinMaxX.y - MinMaxX.x), transform.position.y, transform.position.z);
	}
	
	//Trigger enter
	 void OnTriggerEnter(Collider other)
	{
		Destroy (gameObject);
	}
}
